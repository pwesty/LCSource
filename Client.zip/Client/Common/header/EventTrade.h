
#ifndef		EVENT_TRADE_H_
#define		EVENT_TRADE_H_

struct stEventTrade
{
	int		index;
	int		npc_index;
	int		result_itemIndex;
	int		result_itemCount;

	struct 
	{
		int src_item_idx;
		int	src_item_cnt;
	}
	st_source_item[5];
};


#endif		// EVENT_TRADE_H_