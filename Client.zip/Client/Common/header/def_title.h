
#ifndef		TITLE_DATA_H_
#define		TITLE_DATA_H_

#define DEF_NICK_OPTION_MAX 5
#include "def_base.h"
#pragma pack(push, 1)
struct stTitle : public stTbl_base
{
	BYTE			a_enable;
	char			a_effect[64];
	char			a_attack[64];
	char			a_damage[64];
	unsigned int	a_icolor;
	unsigned int	a_ibgcolor;
	int				a_option_index[DEF_NICK_OPTION_MAX];
	BYTE			a_option_level[DEF_NICK_OPTION_MAX];
	int				a_item_index;
};
#pragma pack(pop)
#endif		// TITLE_DATA_H_