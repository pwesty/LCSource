
#ifndef		COMMAND_H_
#define		COMMAND_H_

class ENGINE_API Command
{
public:
	virtual void execute() = 0;
};


#endif		// COMMAND_H_